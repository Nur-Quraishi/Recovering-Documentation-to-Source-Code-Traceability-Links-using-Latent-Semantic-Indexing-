/***********************************************************
* Developer: Minhas Kamal (minhaskamal024@gmail.com)       *
* Date: 18-Nov-2016                                        *
* License: MIT License                                     *
***********************************************************/

package com.minhaskamal.brailleToTextTranslator.processes.translation.process;

import java.util.ArrayList;

public class BrailleDotOrientationDetectorAdapter {
	public int rowStart = 57;//98;
	public int colStart = 146;//71;
	
	public int rowLength = 40;//58;
	public int colLength = 23;//36;
	
	public double rowGap = 7.35;//5.7;
	public double colGap = 5.9;//2.5;
	
	public int numberOfRows = 27;//23;
	public int numberOfCols = 28;//29;
	
	public double rowShift = -0.002;
	public double colShift = 0.002;
	
	public BrailleDotOrientationDetectorAdapter(ArrayList<int[]> connectedPixelGroupPositions){
		
	}
	
}
