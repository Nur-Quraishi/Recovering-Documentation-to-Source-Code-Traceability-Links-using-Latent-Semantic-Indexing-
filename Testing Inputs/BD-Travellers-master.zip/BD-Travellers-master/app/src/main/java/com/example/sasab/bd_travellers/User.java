package com.example.sasab.bd_travellers;

import java.util.List;

/**
 * Created by sasab on 26-Apr-16.
 */
public class User {
    public String email;
    public String name;
    public String groupId;
    public Boolean admin;
    List<Expenditure> expenditures;
}
