package com.example.sasab.bd_travellers;

/**
 * Created by sasab on 27-Apr-16.
 */
public class Place {
    public String info;
    public String transportNews;
}
