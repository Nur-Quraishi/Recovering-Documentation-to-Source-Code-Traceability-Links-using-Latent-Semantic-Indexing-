package com.example.sasab.bd_travellers;

/**
 * Created by sasab on 27-Apr-16.
 */
public class Expenditure {
    int ID;
    int expense;
    String category;
}
